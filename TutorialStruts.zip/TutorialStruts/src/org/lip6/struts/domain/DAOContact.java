package org.lip6.struts.domain;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DAOContact {
private JDBC jdbc;
	
	

	public String addContact(final long id, final String firstName, final String lastName, final String email) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Creating statement...");
		      String sql1;
		      sql1 = "INSERT INTO contact(firstName, lastName, email) VALUES('" + firstName + "','" + lastName + "','" + email + "')";
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("Contact ajout�e");
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	
}
